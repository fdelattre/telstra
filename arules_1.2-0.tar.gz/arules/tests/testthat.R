library("testthat")
test_package("arules")